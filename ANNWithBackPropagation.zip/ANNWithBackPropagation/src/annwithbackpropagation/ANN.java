package annwithbackpropagation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author Tiyash Basu
 */
public class ANN implements Serializable {
    private int[] nodes;
    private double[][][] weights;
    
    ANN(int[] nodes) {
        int i, j;
        int l = nodes.length;
        this.nodes = new int[l];
        weights = new double[l - 1][][];
        for (i = l - 1; i >= 0; i--)
            this.nodes[i] = nodes[i];
        for (i = l - 1; i >= 1; i--) {
            weights[i - 1] = new double[nodes[i]][];
            for (j = nodes[i] - 1; j >= 0; j--)
                weights[i - 1][j] = new double[nodes[i - 1]];
        }
    }
    
    public boolean Save(String fileName) throws FileNotFoundException, IOException {
        FileOutputStream fOut = new FileOutputStream(fileName);
        ObjectOutputStream oOut = new ObjectOutputStream(fOut);
        oOut.writeObject(this);
        return true;
    }
}
